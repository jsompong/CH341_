//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "CH341DLL.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cspin"
#pragma resource "*.dfm"
TForm1 *Form1;

CHAR buffer;
ULONG DeviceNo = 0; // 0 = first CH341A @ USB, 1 = 2nd, 2 = 3rd, ...

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::OpenBtnClick(TObject *Sender)
{
  CH341OpenDevice(DeviceNo);
  buffer=0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CloseBtnClick(TObject *Sender)
{
  CH341CloseDevice(DeviceNo);
}
//---------------------------------------------------------------------------


void __fastcall TForm1::WriteBtnClick(TObject *Sender)
{
   ULONG bufferlen=1;
   buffer++;
   CH341MemWriteAddr0(DeviceNo, &buffer , &bufferlen); //EVA board LED blink
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DevNoEditChange(TObject *Sender)
{
   DeviceNo = DevNoEdit->Value;
}
//---------------------------------------------------------------------------

