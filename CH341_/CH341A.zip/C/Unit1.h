//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "cspin.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// Komponenten, die von der IDE verwaltet werden
    TButton *OpenBtn;
    TButton *CloseBtn;
    TButton *WriteBtn;
    TCSpinEdit *DevNoEdit;
    TLabel *Label1;
    void __fastcall OpenBtnClick(TObject *Sender);
    void __fastcall CloseBtnClick(TObject *Sender);
    
    void __fastcall WriteBtnClick(TObject *Sender);
    void __fastcall DevNoEditChange(TObject *Sender);
private:	// Benutzerdeklarationen
public:		// Benutzerdeklarationen
    __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
